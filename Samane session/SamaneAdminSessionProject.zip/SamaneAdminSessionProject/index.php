<?php
/*==================================================
MODELE MVC DEVELOPPE PAR Ngor SECK
ngorsecka@gmail.com
(+221) 77 - 433 - 97 - 16
PERFECTIONNEZ CE MODELE ET FAITES MOI UN RETOUR
POUR TOUTE MODIFICATION VISANT A L'AMELIORER.
VOUS ETES LIBRE DE TOUTE UTILISATION.
===================================================*/


require_once 'libs/autoload/Autoloader.class.php';
require_once 'vendor/autoload.php';
use libs\system\Bootstrap;
$bootstrap = new Bootstrap();
?>